//Numpy array shape [3]
//Min -5.000112056732
//Max 9.030755996704
//Number of zeros 0

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b14[3];
#else
output_dense_bias_t b14[3] = {9.0307559967, -4.7412424088, -5.0001120567};
#endif

#endif
