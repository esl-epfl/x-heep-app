//Numpy array shape [3]
//Min -0.174211740494
//Max 0.121577754617
//Number of zeros 0

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b14[3];
#else
output_dense_bias_t b14[3] = {-0.1742117405, 0.1215777546, 0.0771011189};
#endif

#endif
